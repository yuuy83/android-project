import React from 'react';
import Navigation from './navigation';

const App = () => {
    return <Navigation />;
};

export default App;
